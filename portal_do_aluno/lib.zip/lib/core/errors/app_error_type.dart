enum AppErrorType { network, validation, permission, unknown }
