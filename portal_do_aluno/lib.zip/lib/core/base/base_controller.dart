import 'package:flutter/foundation.dart';

abstract class BaseController {

  @mustCallSuper
  void dispose() {}

}