enum AppEnvironmentType {
  development,
  production,
}


