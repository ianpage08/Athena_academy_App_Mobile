class NotificationChanel {
  static const String basicChannelId = 'basic_channel';
  static const String basicChannelName = 'Basic Channel';
  static const String basicChannelDescription = 'Basic Channel Description';
}


