import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:portal_do_aluno/core/errors/app_error.dart';
import 'package:portal_do_aluno/core/errors/app_error_type.dart';
import 'package:portal_do_aluno/core/submit_state/submit_states.dart';
import 'package:portal_do_aluno/features/admin/data/models/comunicado.dart';
import 'package:portal_do_aluno/features/admin/data/repositories/statement_repository.dart';
import 'package:portal_do_aluno/features/admin/helper/form_helper.dart';

class ComunicacaoInstitucionalController {
  // Persistência
  

  // Estado de envio
  final submitState = ValueNotifier<SubmitState>(Initial());
  final StatementRepository _repository = StatementRepository();

  // Formulário
  final formKey = GlobalKey<FormState>();
  final tituloController = TextEditingController();
  final mensagemController = TextEditingController();

  // Campos extras
  PrioridadeComunicado? prioridade;
  String? destinatario;

  // Validação extra
  bool get isFormularioValido => prioridade != null && destinatario != null;

  

  // Envio principal
  Future<void> enviar() async {
    if (!FormHelper.isFormValid(
      formKey: formKey,
      listControllers: [tituloController, mensagemController],
    )) {
      submitState.value = SubmitError(
        AppError(
          type: AppErrorType.validation,
          message: 'Preencha todos os campos',
        ),
      );
      return;
    }

    if (!isFormularioValido) {
      submitState.value = SubmitError(
        AppError(
          type: AppErrorType.validation,
          message: 'Selecione prioridade e destinatário',
        ),
      );
      return;
    }
    submitState.value = SubmitLoading();

    try {
      await _repository.newStatement(
        titulo: tituloController.text.trim(),
        mensagem: mensagemController.text.trim(),
        destinatario: destinatario!,
        prioridade: prioridade!.name,
      );

      await _repository.statementNotification(
        destinatario: destinatario!,
        message: mensagemController.text.trim(),
      );
      clear();
      submitState.value = SubmitSuccess('Comunicado enviado com sucesso!');
    } on FirebaseException {
      submitState.value = SubmitError(
        AppError(
          type: AppErrorType.network,
          message: 'Sem internet, tente novamente mais tarde.',
        ),
      );
    } catch (e) {
      debugPrint(e.toString());

      submitState.value = SubmitError(
        AppError(
          type: AppErrorType.unknown,
          message: 'Erro ao enviar comunicado',
        ),
      );
    }
  }


  // Limpa formulário
  void clear() {
    tituloController.clear();
    mensagemController.clear();
    prioridade = null;
    destinatario = null;
  }

  // Liberação de recursos
  void dispose() {
    submitState.dispose();
    tituloController.dispose();
    mensagemController.dispose();
  }
}
