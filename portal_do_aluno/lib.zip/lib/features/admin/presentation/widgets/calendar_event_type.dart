enum CalendarEventType{
  avaliacao,
  reuniao,
  eventoEscolar,
  outro
}