import 'package:flutter/material.dart';
import 'package:portal_do_aluno/core/submit_state/submit_states.dart';
import 'package:portal_do_aluno/features/admin/presentation/widgets/calendar_event_type.dart';

import 'package:portal_do_aluno/shared/widgets/custom_date_picker_field.dart';
import 'package:portal_do_aluno/shared/widgets/custom_text_form_field.dart';
import 'package:portal_do_aluno/shared/widgets/save_button.dart';

void showCreateCalendarEventModal({
  required BuildContext context,
  required CalendarEventType tipo,
  required Map<String, TextEditingController> controllers,
  required GlobalKey<FormState> formKey,
  required Function(DateTime?) onDateSelected,
  required Future<void> Function(CalendarEventType tipo) salvarconteudo,
  required ValueNotifier<SubmitState> submitState,
}) {
  showModalBottomSheet(
    isScrollControlled: true,
    useSafeArea: true,
    context: context,
    builder: (_) {
      return ValueListenableBuilder<SubmitState>(
        valueListenable: submitState,
        builder: (context, state, _) {
          return Stack(
            children: [
              Padding(
                padding: EdgeInsets.only(
                  left: 16,
                  right: 16,
                  top: 16,
                  bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Marcar novo evento no calendário',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 16),

                    Form(
                      key: formKey,
                      child: Column(
                        children: [
                          CustomTextFormField(
                            controller: controllers['titulo']!,
                            label: 'Título do Evento',
                            hintText: 'Digite o título do evento',
                            prefixIcon: Icons.title,
                          ),
                          const SizedBox(height: 16),
                          CustomTextFormField(
                            controller: controllers['descricao']!,
                            label: 'Descrição do Evento',
                            hintText: 'Digite a descrição do evento',
                            prefixIcon: Icons.description,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    CustomDatePickerField(onDate: onDateSelected),

                    const SizedBox(height: 24),

                    SaveButton(salvarconteudo: () => salvarconteudo(tipo)),
                  ],
                ),
              ),

              //if (isLoading) const Positioned.fill(child: AnimatedOverlay()),
            ],
          );
        },
      );
    },
  );
}
