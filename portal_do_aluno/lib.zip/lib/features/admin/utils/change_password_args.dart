class ChangePasswordArgs {
  final String usuarioId;

  ChangePasswordArgs({required this.usuarioId});
}


