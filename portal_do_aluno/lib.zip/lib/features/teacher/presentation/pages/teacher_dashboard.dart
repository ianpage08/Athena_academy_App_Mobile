import 'package:flutter/material.dart';
import 'package:portal_do_aluno/features/admin/data/datasources/tokens_firestore.dart';
import 'package:portal_do_aluno/features/admin/presentation/providers/user_provider.dart';
import 'package:portal_do_aluno/shared/widgets/navigation_menu_card.dart';
import 'package:portal_do_aluno/shared/widgets/firestore/firestore_document_stream_builder.dart';
import 'package:portal_do_aluno/core/app_constants/colors.dart';
import 'package:portal_do_aluno/core/user/user.dart';
import 'package:portal_do_aluno/navigation/navigation_service.dart';
import 'package:portal_do_aluno/navigation/route_names.dart';
import 'package:portal_do_aluno/shared/widgets/custom_app_bar.dart';
import 'package:portal_do_aluno/features/teacher/presentation/pages/attendace/attendance_registration_page.dart';
import 'package:provider/provider.dart';

class TeacherDashboard extends StatefulWidget {
  const TeacherDashboard({super.key});

  @override
  State<TeacherDashboard> createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  bool _updateToken = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final argumentos =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      if (argumentos != null && argumentos['user'] != null) {
        final userId = argumentos['user']['id'];
        Provider.of<UserProvider>(context, listen: false).setUserId(userId);
      }
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_updateToken) {
      final argumentos =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      if (argumentos != null && argumentos['user'] != null) {
        final userId = argumentos['user']['id'];
        TokensService().gerarToken(userId);
        _updateToken = true;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final usuarioId = Provider.of<UserProvider>(context).userId;
    if (usuarioId == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Area do Professor',
        backGround: AppColors.teacher,
        nameRoute: RouteNames.comunicadosProfessor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Row(
                  children: [
                    Expanded(
                      child: FirestoreDocumentStreamBuilder(
                        collectionPath: 'usuarios',
                        documentId: usuarioId,
                        builder: (context, snapshot) {
                          final data = snapshot.data!.data()!;

                          final dadosUsuario = Usuario.fromJson(data);
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                const CircleAvatar(
                                  radius: 30,
                                  backgroundColor: Color.fromARGB(
                                    255,
                                    152,
                                    177,
                                    243,
                                  ),
                                  child: Icon(
                                    Icons.person,
                                    size: 30,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Admin: ${dadosUsuario.name}',
                                        style: Theme.of(
                                          context,
                                        ).textTheme.titleMedium,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        'Escola: Espaço da Criança',
                                        style: Theme.of(
                                          context,
                                        ).textTheme.titleSmall,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            Expanded(
              child: AnimatedOpacity(
                opacity: 1,
                duration: const Duration(milliseconds: 300),
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  childAspectRatio: 1.45,
                  physics: const BouncingScrollPhysics(),
                  mainAxisSpacing: 10,
                  children: [
                    // NavigationMenuCard: widget personalizado dos botões do menu.
                    // - NavigationService e RouteNames: controle de rotas e nomes das páginas personalizados.
                    NavigationMenuCard(
                      highlight: true,
                      icon: Icons.school,
                      title: 'Frequência',
                      subtitle: 'Lista de presença',
                      onTap: () {
                        NavigatorService.navigateToWithAnimation(
                          const AttendanceRegistrationPage(),
                        );
                      },
                    ),

                    NavigationMenuCard(
                      icon: Icons.assignment,
                      title: 'Lançar Notas',
                      subtitle: 'Notas dos alunos',
                      onTap: () {
                        NavigatorService.navigateTo(RouteNames.boletim);
                      },
                    ),

                    NavigationMenuCard(
                      icon: Icons.menu_book,
                      title: 'Conteúdo da Aula',
                      subtitle: 'Conteúdo lecionado',
                      onTap: () {
                        NavigatorService.navigateTo(RouteNames.addOqueFoiDado);
                      },
                    ),

                    NavigationMenuCard(
                      icon: Icons.note_add,
                      title: 'Exercícios',
                      subtitle: 'Cadastrar atividades',
                      onTap: () {
                        NavigatorService.navigateTo(
                          RouteNames.teacherExercicios,
                        );
                      },
                    ),

                    NavigationMenuCard(
                      icon: Icons.event,
                      title: 'Calendário',
                      subtitle: 'Calendário escolar',
                      onTap: () {
                        NavigatorService.navigateTo(RouteNames.teacherCalendar);
                      },
                    ),

                    NavigationMenuCard(
                      icon: Icons.message,
                      title: 'Comunicados',
                      subtitle: 'Avisos e mensagens',
                      onTap: () {
                        NavigatorService.navigateTo(
                          RouteNames.comunicadosProfessor,
                        );
                      },
                    ),

                    NavigationMenuCard(
                      icon: Icons.settings,
                      title: 'Configurações',
                      subtitle: 'Preferências do sistema',
                      onTap: () {
                        NavigatorService.navigateTo(RouteNames.studentSettings);
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
