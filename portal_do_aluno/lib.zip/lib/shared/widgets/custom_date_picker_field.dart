import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomDatePickerField extends StatefulWidget {
  final DateTime? isSelecionada;
  final Function(DateTime? data) onDate;

  const CustomDatePickerField({
    super.key,
    this.isSelecionada,
    required this.onDate,
  });

  @override
  State<CustomDatePickerField> createState() => _CustomDatePickerFieldState();
}

class _CustomDatePickerFieldState extends State<CustomDatePickerField> {
  late DateTime? dataSelecionada;
  final ValueNotifier<bool> _aberto = ValueNotifier(false);

  @override
  void initState() {
    super.initState();
    dataSelecionada = widget.isSelecionada;
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: _aberto,
      builder: (context, aberto, _) {
        return GestureDetector(
          onTap: () async {
            _aberto.value = true;

            final DateTime? data = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(2010),
              lastDate: DateTime(2030),
            );

            if (data != null) {
              final dataNormalizada = DateTime(
                data.year,
                data.month,
                data.day,
                12,
              );

              setState(() => dataSelecionada = dataNormalizada);
              widget.onDate(dataNormalizada);
            }

            _aberto.value = false;
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(CupertinoIcons.calendar, size: 22),
                    const SizedBox(width: 12),
                    Text(
                      dataSelecionada != null
                          ? '${dataSelecionada!.day}/${dataSelecionada!.month}/${dataSelecionada!.year}'
                          : 'Selecionar Data',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),

                // Ícone com animação igual do BotaoSelecionarTurma
                AnimatedRotation(
                  turns: aberto ? 0.5 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: const Icon(CupertinoIcons.chevron_down, size: 20),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
